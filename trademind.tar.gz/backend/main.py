import asyncio
import json
import threading
import time
from fastapi import FastAPI, Depends, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from backend.config import settings
from backend.database import engine, Base, get_db
from backend.data_engine import market_engine
from backend.ai_engine import AIAnaEngine
from backend.portfolio_manager import PortfolioManager, send_telegram_notification
from backend import models
from backend.backtest_engine import BacktestEngine
from backend.self_evaluation import SelfEvaluationEngine
from backend.regime_detector import MarketRegimeDetector

# Initialize SQLAlchemy Tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.PROJECT_NAME, version="1.0.0")

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



# Active WebSocket connections
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception:
                # Remove stale connection
                pass

manager = ConnectionManager()

# Background task to sync database portfolios with live ticker fluctuations
def run_portfolio_pnl_loop():
    """Loops every 1.5 seconds to compute PnL fluctuations and check SL/Target triggers."""
    print("Background portfolio P&L synchronizer running...")
    last_sync_time = 0.0
    while market_engine.running:
        try:
            # Create a new DB session scope
            from backend.database import SessionLocal
            db = SessionLocal()
            try:
                # Sync balance and watchlists with CoinDCX every 15 seconds
                current_time = time.time()
                if current_time - last_sync_time >= 15.0:
                    market_engine.sync_with_broker(db)
                    last_sync_time = current_time

                # Update P&L
                PortfolioManager.update_positions_pnl(db)
                
                # Check Risk stop-losses/targets
                alerts = PortfolioManager.check_risk_triggers(db)
                if alerts and manager.active_connections:
                    # Send alert details via socket
                    for alert in alerts:
                        asyncio.run(manager.broadcast({
                            "type": "RISK_ALERT",
                            "message": alert,
                            "timestamp": time.time()
                        }))
            finally:
                db.close()
        except Exception as e:
            print(f"Error in portfolio synchronizer loop: {e}")
        time.sleep(1.5)

def run_automated_trading_loop():
    """Loops every 5 seconds. If bot is active, fetches AI signals and executes trades."""
    print("Background automated trading loop running...")
    while market_engine.running:
        try:
            from backend.database import SessionLocal
            db = SessionLocal()
            try:
                user = PortfolioManager.get_or_create_user(db)
                if user.is_bot_active:
                    recommendations = AIAnaEngine.generate_recommendations()
                    signals = [r for r in recommendations if r["action"] in ["BUY", "SELL"]]
                    
                    # Broadcast real-time AI scanning heartbeat to the website console
                    msg_text = f"AI Consensus Engine scanning {len(market_engine.active_symbols)} CoinDCX assets... "
                    if signals:
                        msg_text += f"Detected {len(signals)} potential setup(s). Evaluating triggers..."
                    else:
                        msg_text += "No signals. Re-evaluating setups."
                        
                    asyncio.run(manager.broadcast({
                        "type": "AUTO_ORDER",
                        "message": msg_text,
                        "timestamp": time.time()
                    }))
                    for rec in recommendations:
                        symbol = rec["symbol"]
                        action = rec["action"]
                        confidence = rec["confidence"]
                        quantity = rec["quantity"]
                        price = rec["suggested_price"]
                        
                        if quantity <= 0:
                            continue
                            
                        # Check existing open position in DB
                        position = db.query(models.Position).filter(
                            models.Position.user_id == user.id,
                            models.Position.symbol == symbol
                        ).first()
                        
                        if action == "BUY":
                            # Automatically buy if we don't have an active position
                            if not position:
                                res = PortfolioManager.place_paper_order(
                                    db, 
                                    symbol=symbol, 
                                    order_type="BUY", 
                                    quantity=quantity,
                                    stop_loss=rec["stop_loss"],
                                    target=rec["target"]
                                )
                                if res.get("success"):
                                    print(f"[AUTO-BOT] Automatically BOUGHT {quantity} {symbol} at Rs.{price:.2f}")
                                    # Broadcast order placement through socket
                                    asyncio.run(manager.broadcast({
                                        "type": "AUTO_ORDER",
                                        "message": f"Bought {quantity} {symbol} at Rs.{price:.2f} (Confidence: {confidence*100:.0f}%)",
                                        "timestamp": time.time()
                                    }))
                                else:
                                    print(f"[AUTO-BOT] Failed to place BUY order for {symbol}: {res.get('error')}")
                                    
                        elif action == "SELL":
                            # Automatically sell if we have a position
                            if position:
                                res = PortfolioManager.place_paper_order(
                                    db,
                                    symbol=symbol,
                                    order_type="SELL",
                                    quantity=position.quantity
                                )
                                if res.get("success"):
                                    print(f"[AUTO-BOT] Automatically SOLD/SQUARED-OFF {symbol} at Rs.{price:.2f}")
                                    asyncio.run(manager.broadcast({
                                        "type": "AUTO_ORDER",
                                        "message": f"Sold {position.quantity} {symbol} at Rs.{price:.2f} (AI Sell Signal)",
                                        "timestamp": time.time()
                                    }))
                                else:
                                    print(f"[AUTO-BOT] Failed to place SELL order for {symbol}: {res.get('error')}")
            finally:
                db.close()
        except Exception as e:
            print(f"Error in automated trading loop: {e}")
        time.sleep(1.0)

def run_telegram_polling_loop():
    """Polls Telegram for user commands like /status to allow remote query."""
    import os
    import requests
    token = os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id = os.getenv("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        print("[TELEGRAM] Missing Bot Token or Chat ID. Polling disabled.")
        return
    print("[TELEGRAM] Interactive command polling loop active...")
    last_update_id = 0
    while market_engine.running:
        try:
            url = f"https://api.telegram.org/bot{token}/getUpdates"
            params = {"offset": last_update_id + 1, "timeout": 8}
            res = requests.get(url, params=params, timeout=12)
            if res.status_code == 200:
                data = res.json()
                if data.get("ok"):
                    for update in data.get("result", []):
                        last_update_id = update["update_id"]
                        message = update.get("message", {})
                        from_user = message.get("from", {})
                        text = message.get("text", "").strip()
                        
                        # Only respond if the message comes from the authorized chat ID owner
                        if str(from_user.get("id")) == str(chat_id):
                            if text == "/status":
                                from backend.database import SessionLocal
                                db = SessionLocal()
                                try:
                                    user = PortfolioManager.get_or_create_user(db)
                                    positions = db.query(models.Position).filter(models.Position.user_id == user.id).all()
                                    pos_text = ""
                                    for p in positions:
                                        pos_text += f"• {p.symbol}: {p.quantity:.6f} @ Rs.{p.avg_price:.2f} (P&L: Rs.{p.pnl:+.2f})\n"
                                    if not pos_text:
                                        pos_text = "No active positions."
                                        
                                    free_bal = user.balance
                                    invested_bal = sum(p.quantity * p.avg_price for p in positions)
                                    total_bal = free_bal + invested_bal

                                    reply = f"📊 <b>TradeMind Financial Summary</b>\n\n" \
                                            f"💰 Total Value: <b>Rs.{total_bal:.2f}</b>\n" \
                                            f"📈 Invested Capital: <b>Rs.{invested_bal:.2f}</b>\n" \
                                            f"💵 Free Cash Balance: <b>Rs.{free_bal:.2f}</b>\n\n" \
                                            f"Bot State: <b>{'ACTIVE 🟢' if user.is_bot_active else 'HALTED 🔴'}</b>\n" \
                                            f"Halt Reason: {user.halt_reason or 'None'}\n\n" \
                                            f"<b>Active Holdings:</b>\n{pos_text}"
                                    send_telegram_notification(reply)
                                except Exception as ex:
                                    print(f"Error compiling status response: {ex}")
                                finally:
                                    db.close()
        except Exception as e:
            print(f"Error in Telegram polling loop: {e}")
        time.sleep(2.0)

# Thread listener that acts as a callback target for our data engine ticks
def handle_live_tick(tick_info: dict):
    """Callback triggered whenever a market asset fluctuates in price."""
    # We broadcast this tick to all connected React dashboards
    if manager.active_connections:
        # Use asyncio to push JSON in a thread-safe way
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            
        coro = manager.broadcast({
            "type": "TICK",
            "data": tick_info
        })
        
        if loop.is_running():
            asyncio.run_coroutine_threadsafe(coro, loop)
        else:
            loop.run_until_complete(coro)

@app.on_event("startup")
def startup_event():
    # Setup broker callbacks
    market_engine.subscribe(handle_live_tick)
    # Sync active symbols from database connections
    db = next(get_db())
    try:
        from backend.config import settings
        from backend.portfolio_manager import PortfolioManager
        user = PortfolioManager.get_or_create_user(db)
        
        # Auto-seed or update CoinDCX API connection on startup with hardcoded environment keys
        conn = db.query(models.BrokerConnection).filter(
            models.BrokerConnection.user_id == user.id,
            models.BrokerConnection.broker_name == "CoinDCX API"
        ).first()
        
        if not conn:
            conn = models.BrokerConnection(
                user_id=user.id,
                broker_name="CoinDCX API",
                client_id=settings.COINDCX_API_KEY,
                access_token=settings.COINDCX_API_SECRET,
                is_active=True
            )
            db.add(conn)
            db.commit()
            print("Successfully seeded active CoinDCX API connection on startup.")
        else:
            if conn.client_id != settings.COINDCX_API_KEY or conn.access_token != settings.COINDCX_API_SECRET or not conn.is_active:
                conn.client_id = settings.COINDCX_API_KEY
                conn.access_token = settings.COINDCX_API_SECRET
                conn.is_active = True
                db.commit()
                print("Successfully updated active CoinDCX API connection on startup.")
                
        market_engine.sync_with_broker(db)
    finally:
        db.close()
    # Start price updates
    market_engine.start_simulation()
    # Start portfolio tracking thread
    pnl_thread = threading.Thread(target=run_portfolio_pnl_loop, daemon=True)
    pnl_thread.start()
    # Start automated trading bot loop thread
    bot_thread = threading.Thread(target=run_automated_trading_loop, daemon=True)
    bot_thread.start()
    # Start interactive Telegram command listener
    tg_thread = threading.Thread(target=run_telegram_polling_loop, daemon=True)
    tg_thread.start()

@app.on_event("shutdown")
def shutdown_event():
    market_engine.unsubscribe(handle_live_tick)
    market_engine.stop_simulation()

# WebSocket Route
@app.websocket("/api/v1/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Keep connection alive by receiving messages
            data = await websocket.receive_text()
            # Respond to ping
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# API ENDPOINTS

@app.get("/api/v1/market/summary")
def get_market_summary():
    """Returns the latest ticker states for Indices and Equities."""
    results = {}
    # Always include index symbols
    for sym in settings.INDEX_SYMBOLS:
        results[sym] = market_engine.get_latest_data(sym)
    # Include all actively tracked symbols (broker or simulation)
    for sym in market_engine.active_symbols:
        results[sym] = market_engine.get_latest_data(sym)
    return results

@app.get("/api/v1/market/candles/{symbol}")
def get_candles(symbol: str):
    """Returns 30 recent daily candles for charting purposes."""
    if symbol not in market_engine.historical_data:
        raise HTTPException(status_code=404, detail="Symbol not tracked")
        
    df = market_engine.historical_data[symbol]
    candles = []
    for index, row in df.iterrows():
        candles.append({
            "time": int(index.timestamp()),
            "open": float(row["Open"]),
            "high": float(row["High"]),
            "low": float(row["Low"]),
            "close": float(row["Close"]),
            "volume": int(row["Volume"]),
            "rsi": float(row.get("RSI_14", 50)),
            "macd": float(row.get("MACD", 0)),
            "macd_signal": float(row.get("MACD_Signal", 0))
        })
    return {"symbol": symbol, "candles": candles}

@app.get("/api/v1/ai/recommendations")
def get_ai_recommendations():
    """Computes technical models consensus for all watchlist assets."""
    return AIAnaEngine.generate_recommendations()

@app.get("/api/v1/portfolio/summary")
def get_portfolio_summary(db: Session = Depends(get_db)):
    """Computes cash reserves, active open positions, holdings and trading history."""
    user = PortfolioManager.get_or_create_user(db)
    
    positions = db.query(models.Position).filter(models.Position.user_id == user.id).all()
    trades = db.query(models.Trade).filter(models.Trade.user_id == user.id).order_by(models.Trade.timestamp.desc()).limit(30).all()
    brokers = db.query(models.BrokerConnection).filter(models.BrokerConnection.user_id == user.id).all()
    
    pos_list = []
    for pos in positions:
        pos_list.append({
            "id": pos.id,
            "symbol": pos.symbol,
            "quantity": pos.quantity,
            "avg_price": round(pos.avg_price, 2),
            "current_price": round(pos.current_price, 2),
            "pnl": round(pos.pnl, 2)
        })
        
    trade_list = []
    for trade in trades:
        trade_list.append({
            "id": trade.id,
            "symbol": trade.symbol,
            "order_type": trade.order_type,
            "trade_type": trade.trade_type,
            "quantity": trade.quantity,
            "price": round(trade.price, 2),
            "stop_loss": round(trade.stop_loss, 2) if trade.stop_loss else None,
            "target": round(trade.target, 2) if trade.target else None,
            "status": trade.status,
            "pnl": round(trade.pnl, 2),
            "timestamp": trade.timestamp.isoformat()
        })
        
    broker_list = []
    for broker in brokers:
        broker_list.append({
            "broker_name": broker.broker_name,
            "client_id": broker.client_id,
            "connected_at": broker.connected_at.isoformat(),
            "is_active": broker.is_active
        })

    return {
        "balance": round(user.balance, 2),
        "margin": round(user.margin, 2),
        "daily_pnl": round(user.daily_pnl, 2),
        "total_value": round(user.balance + sum(pos.pnl + (pos.avg_price * pos.quantity) for pos in positions), 2),
        "positions": pos_list,
        "trades": trade_list,
        "connected_brokers": broker_list,
        "is_bot_active": user.is_bot_active,
        "halt_reason": user.halt_reason
    }


@app.post("/api/v1/portfolio/order")
def execute_order(order: dict, db: Session = Depends(get_db)):
    """Executes a buy or sell paper trade transaction."""
    required = ["symbol", "order_type", "quantity"]
    for field in required:
        if field not in order:
            raise HTTPException(status_code=400, detail=f"Missing field: {field}")
            
    symbol = order["symbol"]
    order_type = order["order_type"].upper()
    quantity = float(order["quantity"])
    stop_loss = order.get("stop_loss")
    target = order.get("target")
    
    if order_type not in ["BUY", "SELL"]:
        raise HTTPException(status_code=400, detail="order_type must be BUY or SELL")
    if quantity <= 0:
        raise HTTPException(status_code=400, detail="quantity must be greater than 0")
        
    result = PortfolioManager.place_paper_order(
        db, symbol, order_type, quantity, stop_loss, target
    )
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["error"])
        
    return result

@app.post("/api/v1/broker/connect")
def connect_broker(conn: dict, db: Session = Depends(get_db)):
    """Simulates broker authorization callback and registers credentials."""
    required = ["broker_name", "client_id", "access_token"]
    for field in required:
        if field not in conn:
            raise HTTPException(status_code=400, detail=f"Missing field: {field}")
            
    user = PortfolioManager.get_or_create_user(db)
    
    # Check if this broker is already connected
    existing = db.query(models.BrokerConnection).filter(
        models.BrokerConnection.user_id == user.id,
        models.BrokerConnection.broker_name == conn["broker_name"]
    ).first()
    
    if existing:
        existing.client_id = conn["client_id"]
        existing.access_token = conn["access_token"]
        existing.is_active = True
        existing.connected_at = datetime.datetime.utcnow()
    else:
        new_conn = models.BrokerConnection(
            user_id=user.id,
            broker_name=conn["broker_name"],
            client_id=conn["client_id"],
            access_token=conn["access_token"],
            is_active=True
        )
        db.add(new_conn)
        
    db.commit()
    # Dynamically sync assets from connected broker API
    market_engine.sync_with_broker(db)
    return {"status": "success", "message": f"Successfully connected to {conn['broker_name']}"}

@app.post("/api/v1/portfolio/bot/toggle")
def toggle_bot(db: Session = Depends(get_db)):
    """Toggles the AI automated bot state on/off, clearing halt reasons if enabling."""
    user = PortfolioManager.get_or_create_user(db)
    user.is_bot_active = not user.is_bot_active
    if user.is_bot_active:
        user.halt_reason = None
        # Reset the drawdown peak to current actual portfolio value to clear legacy paper trade peaks
        positions = db.query(models.Position).filter(models.Position.user_id == user.id).all()
        holdings_value = sum(float(pos.current_price) * float(pos.quantity) for pos in positions if pos.current_price)
        user.peak_value = user.balance + holdings_value
    db.commit()
    return {"status": "success", "is_bot_active": user.is_bot_active, "halt_reason": user.halt_reason}

@app.get("/api/v1/backtest")
def run_strategy_backtest(symbol: str, strategy: str, days: int = 60):
    """Triggers the backtesting engine on historical intraday bars."""
    return BacktestEngine.run_backtest(symbol, strategy, days)

@app.get("/api/v1/portfolio/evaluation")
def get_portfolio_evaluation(db: Session = Depends(get_db)):
    """Computes a detailed Weekly Performance Report based on Learning Log records."""
    report_md = SelfEvaluationEngine.generate_weekly_report(db)
    return {"report": report_md}



# Serve React static build if dist exists
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

dist_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "dist")
if os.path.exists(dist_dir):
    app.mount("/assets", StaticFiles(directory=os.path.join(dist_dir, "assets")), name="assets")
    
    @app.get("/{catchall:path}")
    async def serve_react(catchall: str):
        if catchall.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not Found")
        return FileResponse(os.path.join(dist_dir, "index.html"))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
